﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace bialphasprog
{
	class Program
	{
		static void Main(string[] args)
		{
			// Will Be Used later to separate into bialphas.
			int pair = 0;

			string filename;

			if (args.Length == 0)
			{
				Console.Write("file path:");
				filename = Console.ReadLine();
			}
			else
			{
				filename = args[0];
			}

			string[] phraseArray = File.ReadAllLines(filename);

			//ShowPhrases(phrase1);

			List<string> phrases = phraseArray.ToList<string>();

			RemoveSpecialCharacters(ref phrases);
			ReplaceSpecialCharacters(ref phrases);

			//ShowPhrases(phrases);

			ReplaceNumerics(ref phrases);

			ShowPhrases(phrases);
		}

		private static void ShowPhrases(string[] phrases)
		{
			foreach (string phrase in phrases)
			{
				Console.WriteLine(phrase);
			}
		}

		private static void ShowPhrases(List<string> phrases)
		{
			foreach (string phrase in phrases)
			{
				Console.WriteLine(phrase);
			}
		}

		private static void RemoveSpecialCharacters(ref List<string> phrases)
		{
			string[] charactersToRemove = { "@", "_", "-", "(", ")", "+", "=" };

			for (int i = 0; i < phrases.Count; ++i)
			{
				foreach (string character in charactersToRemove)
				{
					phrases[i] = phrases[i].Replace(character, "");
				}
			}
		}

		private static void ReplaceSpecialCharacters(ref List<string> phrases)
		{
			for (int i = 0; i < phrases.Count; ++i)
			{
				phrases[i] = phrases[i].Replace(".", " END SENTENCE ");
			}
		}

		private static void ReplaceNumerics(ref List<string> phrases)
		{
			for (int i = 0; i < phrases.Count; ++i)
			{
				phrases[i] = phrases[i].Replace("0", "ZERO ");
				phrases[i] = phrases[i].Replace("1", "ONE ");
				phrases[i] = phrases[i].Replace("2", "TWO ");
				phrases[i] = phrases[i].Replace("3", "THREE ");
				phrases[i] = phrases[i].Replace("4", "FOUR ");
				phrases[i] = phrases[i].Replace("5", "FIVE ");
				phrases[i] = phrases[i].Replace("6", "SIX ");
				phrases[i] = phrases[i].Replace("7", "SEVEN ");
				phrases[i] = phrases[i].Replace("8", "EIGHT ");
				phrases[i] = phrases[i].Replace("9", "NINE ");
				phrases[i] = phrases[i].Replace(".", " END SENTENCE ");
			}
		}
	}
}